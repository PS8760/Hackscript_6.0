import os
from flask import Flask, request, jsonify
from flask_cors import CORS
import pandas as pd
import numpy as np
from statsmodels.tsa.arima.model import ARIMA
import matplotlib.pyplot as plt
from io import BytesIO
import base64

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

# Load dataset
file_path = r"C:\Users\iqras\Downloads\commodity_prices_updated1.csv"
if not os.path.exists(file_path):
    print(f"Error: File not found at {file_path}")
    exit()

df = pd.read_csv(file_path)
df['Date'] = pd.to_datetime(df['Date'], errors='coerce')
df.dropna(subset=['Date', "Commodity", "State", "District"], inplace=True)  # Drop rows with missing values
df = df.sort_values(by='Date')

@app.route('/predict', methods=['POST'])
def predict():
    # Get user input
    data = request.json
    commodity = data['commodity'].strip().title()
    state = data['state'].strip().title()
    district = data['district'].strip().title()
    date_str = data['date']

    # Debug: Print unique values
    print("Unique Commodities:", df["Commodity"].unique())
    print("Unique States:", df["State"].unique())
    print("Unique Districts:", df["District"].unique())

    # Filter dataset
    df_filtered = df[
        (df["Commodity"].str.strip().str.title() == commodity) &
        (df["State"].str.strip().str.title() == state) &
        (df["District"].str.strip().str.title() == district)
    ].copy()

    # Debug: Print filtered data
    print("Filtered Data:", df_filtered)

    if df_filtered.empty:
        return jsonify({"error": "No data found for the given inputs."}), 400

    # Rest of the code...
    # ARIMA Model
    df_filtered.set_index('Date', inplace=True)
    df_filtered = df_filtered[['Price']].asfreq('ME').ffill()

    try:
        arima_model = ARIMA(df_filtered, order=(5, 1, 0))
        arima_fit = arima_model.fit()
    except Exception as e:
        return jsonify({"error": f"ARIMA model training failed: {e}"}), 500

    # Forecast
    forecast_steps = 12
    forecast_dates = pd.date_range(df_filtered.index[-1] + pd.DateOffset(months=1), periods=forecast_steps, freq='ME')
    forecast_values = arima_fit.forecast(steps=forecast_steps)
    forecast_df = pd.DataFrame({"Forecasted Price": forecast_values}, index=forecast_dates)

    # Get forecasted price for the user's date
    try:
        date = pd.to_datetime(date_str)
        nearest_date = forecast_df.index[forecast_df.index.get_indexer([date], method="nearest")[0]]
        forecasted_price = forecast_df.loc[nearest_date, 'Forecasted Price']
    except (KeyError, ValueError):
        return jsonify({"error": "Invalid date. Please enter a valid date in YYYY-MM-DD format within the forecast range."}), 400

    # Generate plot
    plt.figure(figsize=(12, 5))
    plt.plot(df_filtered.index, df_filtered['Price'], label="Actual Prices", marker='o')
    plt.plot(forecast_df.index, forecast_df["Forecasted Price"], label="Forecasted Prices", linestyle="dashed", color="red", marker='x')
    plt.xlabel("Year")
    plt.ylabel("Price (₹)")
    plt.title(f"ARIMA Forecast for {commodity} in {district}, {state}")
    plt.legend()
    plt.grid()

    # Save plot to a BytesIO object
    buf = BytesIO()
    plt.savefig(buf, format='png')
    buf.seek(0)
    plot_data = base64.b64encode(buf.getvalue()).decode('utf-8')
    plt.close()

    # Return response
    return jsonify({
        "forecasted_price": forecasted_price,
        "plot": plot_data
    })

if __name__ == '__main__':
    app.run(debug=True)