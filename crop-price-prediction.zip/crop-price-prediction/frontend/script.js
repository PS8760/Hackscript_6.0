document.getElementById('predictionForm').addEventListener('submit', async (e) => {
    e.preventDefault();

    const commodity = document.getElementById('commodity').value;
    const state = document.getElementById('state').value;
    const district = document.getElementById('district').value;
    const date = document.getElementById('date').value;

    const response = await fetch('http://127.0.0.1:5000/predict', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            commodity,
            state,
            district,
            date,
        }),
    });

    const data = await response.json();

    if (data.error) {
        alert(data.error);
    } else {
        document.getElementById('price').innerText = `Forecasted Price: ₹${data.forecasted_price.toFixed(2)}`;
        document.getElementById('plot').src = `data:image/png;base64,${data.plot}`;
    }
});